const jwt = require('jsonwebtoken');

const authenticateToken = (req, res, next) => {
  // Get token from Authorization header
  const token = req.header("Authorization") && req.header("Authorization").split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." });
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, "99a61525883dc1c0fabaa64de75eb6e8ebf179dc076ed7832068c7f9f264d0138637b334fdad8a52d5e1f14f2454ad3d1a25efb6b7a3cfc1ef962bec53f44018");

    // Attach user information to the request object
    req.user = decoded;

    // Call next middleware or route handler
    next();
  } catch (err) {
    return res.status(400).json({ message: "Invalid token." });
  }
};

module.exports = authenticateToken;
