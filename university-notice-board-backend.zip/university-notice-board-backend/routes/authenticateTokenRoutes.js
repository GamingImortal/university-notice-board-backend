const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/authToken');
const User = require('../models/User');

// Protected route that requires the user to be logged in
router.get("/profile", authenticateToken, async (req, res) => {
  try {
    // The `req.user` object will have the decoded JWT data (e.g., user._id)
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Send back user profile info (excluding password)
    const { password, ...userData } = user._doc; // Remove password field before sending
    res.json(userData);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error fetching user profile" });
  }
});

module.exports = router;
