const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const router = express.Router();

// Register a user
router.post("/register", async (req, res) => {
  const { name, email, major, password, role } = req.body;

  // Log the incoming request
  console.log(`POST /register - Request received with email: ${email}`);

  // Check if the email has the correct domain
  const emailRegex = /^[a-zA-Z0-9._%+-]+@students\.uz\.ac\.zw$/;
  if (!emailRegex.test(email)) {
    console.log(`POST /register - Validation failed: Invalid email domain for ${email}`);
    return res.status(400).json({ message: "Email must be from the domain @students.uz.ac.zw" });
  }

  try {
    // Hash the password before saving
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const user = new User({
      name,
      email,
      major,
      password: hashedPassword,
      role,
    });

    // Save the user to the database
    const newUser = await user.save();

    // Log success
    console.log(`POST /register - Success: User registered with email ${email}`);
    
    // Respond with the new user object
    res.status(201).json(newUser);
  } catch (err) {
    // Log failure
    console.log(`POST /register - Failure: Error registering user ${email} - ${err.message}`);
    
    res.status(400).json({ message: err.message });
  }
});


// Login a user
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  // Log the incoming login request
  console.log(`POST /login - Request received with email: ${email}`);

  try {
    // Check if the user exists in the database
    const user = await User.findOne({ email });
    if (!user) {
      console.log(`POST /login - Failure: User not found with email ${email}`);
      return res.status(404).json({ message: "User not found" });
    }

    // Check if the password is correct
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      console.log(`POST /login - Failure: Invalid credentials for email ${email}`);
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Generate a JWT token for the user
    const token = jwt.sign({ id: user._id, role: user.role }, "99a61525883dc1c0fabaa64de75eb6e8ebf179dc076ed7832068c7f9f264d0138637b334fdad8a52d5e1f14f2454ad3d1a25efb6b7a3cfc1ef962bec53f44018", {
      expiresIn: "1d",
    });

    // Log the successful login
    console.log(`POST /login - Success: User logged in with email ${email}`);

    // Respond with the token and user info
    res.json({ token, user });
  } catch (err) {
    // Log the error
    console.log(`POST /login - Failure: Error during login attempt for email ${email} - ${err.message}`);
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
